
document.addEventListener('DOMContentLoaded', () => {
    const xmlUrls = {
        Hotel: 'http://api.et4.de/Schema/eTouristV4/Vermieter/Sachsen-Tourismus/VermieterTree.xml',
        Event: 'http://api.et4.de/Schema/eTouristV4/Veranstaltung/Sachsen-Tourismus/VeranstaltungTree.xml',
        Gastro: 'http://api.et4.de/Schema/eTouristV4/Gastro/Sachsen-Tourismus/GastroTree.xml',
        Tour: 'http://api.et4.de/Schema/eTouristV4/Tour/Sachsen-Tourismus/TourTree.xml',
        POI: 'http://api.et4.de/Schema/eTouristV4/Poi/Sachsen-Tourismus/POITree.xml'
    };

    const apiUrl = 'https://meta.et4.de/rest.ashx/search/?experience=statistik_sachsen&type={{TYPE}}{{QUERY}}&template=ET2014A.xml';
    const openDataUrl = 'https://meta.et4.de/rest.ashx/search/?experience=statistik_sachsen&type={{TYPE}}&{{QUERY}}+AND+attribute_license%3A(CC0+OR+CC-BY+OR+CC-BY-SA)&template=ET2014A.xml';
    const openDataUrl_2 = 'https://meta.et4.de/rest.ashx/search/?experience=statistik_sachsen&type={{TYPE}}&q=attribute_license%3A(CC0+OR+CC-BY+OR+CC-BY-SA)&template=ET2014A.xml';


    const elements = {
        container: document.getElementById('dropdown-container'),
        typeContainer: document.getElementById('type-dropdown-container'),
        areaContainer: document.getElementById('area-dropdown-container'),
        cityContainer: document.getElementById('city-dropdown-container'),
        placeContainer: document.getElementById('place-dropdown-container'),
        button: document.getElementById('search-button'),
        resultDiv: document.getElementById('result'),
        generatedUrlDiv: document.getElementById('generated-url'),
        chartContainer: document.getElementById('chart-container'),
        allAreasCheckbox: document.getElementById('all-areas-checkbox'),
        loadingContainer: document.getElementById('loading-container'),
        coffeeFill: document.getElementById('coffee-fill')
    };

    let selectedCategory = null;
    let selectedType = null;
    let selectedArea = null;
    let selectedCity = null;
    let selectedPlace = null;
    let categories = [];

    const toggleLoading = (isLoading) => {
        elements.loadingContainer.style.display = isLoading ? 'flex' : 'none';
        elements.coffeeFill.style.transform = isLoading ? 'scaleY(1)' : 'scaleY(0)';
    };

    const parseXMLForCount = (data) => {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(data, 'application/xml');
        return xmlDoc.getElementsByTagName('overallcount')[0]?.textContent || '0';
    };

    const disableInputs = (disable) => {
        const inputs = [elements.typeContainer, elements.areaContainer, elements.cityContainer, elements.placeContainer];
        inputs.forEach(input => {
            const dropdown = input.querySelector('select');
            if (dropdown) dropdown.disabled = disable;
        });
    };

    const displayTable = (data) => {
    elements.resultDiv.innerHTML = ''; // Clear the table before displaying a new one
    const table = document.createElement('table');
    table.innerHTML = `
        <thead>
            <tr>
                <th>Gebiet</th>
                <th>Ort</th>
                <th>Typ</th>
                <th>Kategorie</th>
                <th>SaTourN</th>
                <th>Open-Data</th>
                <th>Open-Data-Prozentsatz</th>
            </tr>
        </thead>
        <tbody></tbody>
    `;

    const tbody = table.querySelector('tbody');

    let totalStatistik = 0;
    let totalOpenData = 0;
    let totalPercentage = 0;
    let count = 0;

    data.forEach(({ area, city, place, type, category, statistikCount, openDataCount }) => {
        const openDataPercentage = statistikCount > 0 ? ((openDataCount / statistikCount) * 100).toFixed(2) : '0.00';
        const displayCategory = category || '-';

        totalStatistik += parseInt(statistikCount, 10);
        totalOpenData += parseInt(openDataCount, 10);
        totalPercentage += parseFloat(openDataPercentage);
        count++;

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${area}</td>
            <td>${place}</td>
            <td>${type}</td>
            <td>${displayCategory}</td>
            <td>${statistikCount}</td>
            <td>${openDataCount}</td>
            <td>${openDataPercentage}%</td>
        `;
        tbody.appendChild(row);
    });

    // Durchschnitt des Open-Data-Prozentsatzes berechnen
    const avgPercentage = count > 0 ? (totalPercentage / count).toFixed(2) : '0.00';

    // Gesamtzeile hinzufügen
    const totalRow = document.createElement('tr');
    totalRow.style.fontWeight = 'bold';
    totalRow.innerHTML = `
        <td colspan="4">Gesamt</td>
        <td>${totalStatistik}</td>
        <td>${totalOpenData}</td>
        <td>${avgPercentage}%</td>
    `;
    tbody.appendChild(totalRow);

    elements.resultDiv.innerHTML = '';
    elements.resultDiv.appendChild(table);
};


    const fetchData = () => {
        const queries = [];
        const types = ['POI', 'Tour', 'Hotel', 'Event', 'Gastro'];

        if (elements.allAreasCheckbox.checked) {
            // Checkbox aktiviert: Alle Typen für jedes Gebiet abfragen
            fetch('https://meta.et4.de/rest.ashx/search/?experience=statistik_sachsen&type=Area&template=ET2014A.xml')
                .then(response => response.ok ? response.text() : Promise.reject(response.status))
                .then(data => {
                    const parser = new DOMParser();
                    const xmlDoc = parser.parseFromString(data, 'application/xml');
                    const areas = Array.from(xmlDoc.getElementsByTagName('item'));
                    toggleLoading(true);
                    areas.forEach(areaItem => {
                        const areaTitle = areaItem.getElementsByTagName('title')[0]?.textContent;
                        if (areaTitle) {
                            types.forEach(type => {
                                const query = `&q=area%3A%22${encodeURIComponent(areaTitle)}%22`;
                                queries.push(
                                    fetch(apiUrl.replace('{{TYPE}}', type).replace('{{QUERY}}', query)).then(res => res.text()),
                                    fetch(openDataUrl.replace('{{TYPE}}', type).replace('{{QUERY}}', query)).then(res => res.text())
                                );
                            });
                        }
                    });

                    Promise.all(queries).then(responses => {
                        const data = [];
                        responses.forEach((response, index) => {
                            if (index % 2 === 0) {
                                const statistikCount = parseXMLForCount(response);
                                const openDataCount = parseXMLForCount(responses[index + 1]);
                                const type = types[Math.floor(index / 2) % types.length];
                                const area = areas[Math.floor(index / (2 * types.length))]?.getElementsByTagName('title')[0]?.textContent || 'Unbekannt';

                                data.push({
                                    area,
                                    place: '-',
                                    type,
                                    category: '-',
                                    statistikCount,
                                    openDataCount
                                });
                            }
                        });
                        displayTable(data);
                        toggleLoading(false);
                    }).catch(error => {
                        console.error('Fehler bei der Abfrage:', error);
                        elements.resultDiv.textContent = 'Fehler bei der Abfrage. Bitte versuchen Sie es später erneut.';
                        toggleLoading(false);
                    });
                })
                .catch(error => {
                    console.error('Fehler beim Laden der Gebiete:', error);
                    elements.resultDiv.textContent = 'Fehler beim Laden der Gebiete. Bitte versuchen Sie es später erneut.';
                    toggleLoading(false);
                });
        } else if (!selectedArea && !selectedPlace && selectedType) {
            // Neuer Fall: Kein Gebiet, kein Ort, aber ein Typ
            fetch('https://meta.et4.de/rest.ashx/search/?experience=statistik_sachsen&type=Area&template=ET2014A.xml')
                .then(response => response.ok ? response.text() : Promise.reject(response.status))
                .then(data => {
                    const parser = new DOMParser();
                    const xmlDoc = parser.parseFromString(data, 'application/xml');
                    const areas = Array.from(xmlDoc.getElementsByTagName('item'));
                    toggleLoading(true);
                    areas.forEach(areaItem => {
                        const areaTitle = areaItem.getElementsByTagName('title')[0]?.textContent;
                        if (areaTitle) {
                            const query = `&q=area%3A%22${encodeURIComponent(areaTitle)}%22`;
                            queries.push(
                                fetch(apiUrl.replace('{{TYPE}}', selectedType).replace('{{QUERY}}', query)).then(res => res.text()),
                                fetch(openDataUrl.replace('{{TYPE}}', selectedType).replace('{{QUERY}}', query)).then(res => res.text())
                            );
                        }
                    });

                    Promise.all(queries).then(responses => {
                        const data = [];
                        responses.forEach((response, index) => {
                            if (index % 2 === 0) {
                                const statistikCount = parseXMLForCount(response);
                                const openDataCount = parseXMLForCount(responses[index + 1]);
                                const area = areas[Math.floor(index / 2)]?.getElementsByTagName('title')[0]?.textContent || 'Unbekannt';

                                data.push({
                                    area,
                                    city: '-',
                                    place: '-',
                                    type: selectedType,
                                    category: '-',
                                    statistikCount,
                                    openDataCount
                                });
                            }
                        });
                        displayTable(data);
                        toggleLoading(false);
                    }).catch(error => {
                        console.error('Fehler bei der Abfrage:', error);
                        elements.resultDiv.textContent = 'Fehler bei der Abfrage. Bitte versuchen Sie es später erneut.';
                        toggleLoading(false);
                    });
                })
                .catch(error => {
                    console.error('Fehler beim Laden der Gebiete:', error);
                    elements.resultDiv.textContent = 'Fehler beim Laden der Gebiete. Bitte versuchen Sie es später erneut.';
                    toggleLoading(false);
                });
        } else if (!selectedArea && !selectedPlace && !selectedType) {
            // Fall 1: Kein Gebiet, kein Ort, kein Typ
            types.forEach(type => {
                const query = '';
                queries.push(
                    fetch(apiUrl.replace('{{TYPE}}', type).replace('{{QUERY}}', query)).then(res => res.text()),
                    fetch(openDataUrl_2.replace('{{TYPE}}', type)).then(res => res.text())
                );
            });
        } else if (selectedArea && !selectedType && !selectedPlace) {
            // Fall 2: Gebiet gewählt, kein Typ, kein Ort
            types.forEach(type => {
                const query = `&q=area%3A%22${encodeURIComponent(selectedArea)}%22`;
                queries.push(
                    fetch(apiUrl.replace('{{TYPE}}', type).replace('{{QUERY}}', query)).then(res => res.text()),
                    fetch(openDataUrl.replace('{{TYPE}}', type).replace('{{QUERY}}', query)).then(res => res.text())
                );
            });
        } else if (selectedArea && selectedType && !selectedPlace) {
            // Fall 3: Gebiet gewählt, Typ gewählt, kein Ort
            categories.forEach(category => {
                const query = `&q=area%3A%22${encodeURIComponent(selectedArea)}%22+AND+category%3A%22${encodeURIComponent(category)}%22`;
                queries.push(
                    fetch(apiUrl.replace('{{TYPE}}', selectedType).replace('{{QUERY}}', query)).then(res => res.text()),
                    fetch(openDataUrl.replace('{{TYPE}}', selectedType).replace('{{QUERY}}', query)).then(res => res.text())
                );
            });
        } else if (selectedPlace && selectedType && !selectedArea) {
            // Fall 4: Ort gewählt, Typ gewählt, kein Gebiet
            categories.forEach(category => {
                const query = `&q=city%3A%22${encodeURIComponent(selectedPlace)}%22+AND+category%3A%22${encodeURIComponent(category)}%22`;
                queries.push(
                    fetch(apiUrl.replace('{{TYPE}}', selectedType).replace('{{QUERY}}', query)).then(res => res.text()),
                    fetch(openDataUrl.replace('{{TYPE}}', selectedType).replace('{{QUERY}}', query)).then(res => res.text())
                );
            });
        } else if (!selectedType && selectedPlace && selectedArea) {
            // Fall 5: Gebiet und Ort gewählt, kein Typ
            types.forEach(type => {
                const query = `&q=area%3A%22${encodeURIComponent(selectedArea)}%22+AND+city%3A%22${encodeURIComponent(selectedPlace)}%22`;
                queries.push(
                    fetch(apiUrl.replace('{{TYPE}}', type).replace('{{QUERY}}', query)).then(res => res.text()),
                    fetch(openDataUrl.replace('{{TYPE}}', type).replace('{{QUERY}}', query)).then(res => res.text())
                );
            });
        } else if (selectedType && selectedPlace && selectedArea) {
            // Fall 6: Gebiet, Ort und Typ gewählt
            if (categories.length === 0) {
                const query = `&q=area%3A%22${encodeURIComponent(selectedArea)}%22+AND+city%3A%22${encodeURIComponent(selectedPlace)}%22`;
                queries.push(
                    fetch(apiUrl.replace('{{TYPE}}', selectedType).replace('{{QUERY}}', query)).then(res => res.text()),
                    fetch(openDataUrl.replace('{{TYPE}}', selectedType).replace('{{QUERY}}', query)).then(res => res.text())
                );
            } else {
                categories.forEach(category => {
                    const query = `&q=area%3A%22${encodeURIComponent(selectedArea)}%22+AND+city%3A%22${encodeURIComponent(selectedPlace)}%22+AND+category%3A%22${encodeURIComponent(category)}%22`;
                    queries.push(
                        fetch(apiUrl.replace('{{TYPE}}', selectedType).replace('{{QUERY}}', query)).then(res => res.text()),
                        fetch(openDataUrl.replace('{{TYPE}}', selectedType).replace('{{QUERY}}', query)).then(res => res.text())
                    );
                });
            }
        }

        Promise.all(queries).then(responses => {
            const data = [];
            responses.forEach((response, index) => {
                if (index % 2 === 0) {
                    const statistikCount = parseXMLForCount(response);
                    const openDataCount = parseXMLForCount(responses[index + 1]);
                    const type = selectedType || types[Math.floor(index / 2)];
                    const category = categories[Math.floor((index % (2 * categories.length)) / 2)] || '-';

                    data.push({
                        area: selectedArea || 'Sachsen',
                        city: selectedCity || '-',
                        place: selectedPlace || '-',
                        type,
                        category,
                        statistikCount,
                        openDataCount
                    });
                }
            });
            displayTable(data);
            toggleLoading(false);
        }).catch(error => {
            console.error('Fehler bei der Abfrage:', error);
            elements.resultDiv.textContent = 'Fehler bei der Abfrage. Bitte versuchen Sie es später erneut.';
            toggleLoading(false);
        });
    };

    const loadPlaces = (area) => {
        let query = '';
        if (area) {
            query = `&q=area%3A%22${encodeURIComponent(area)}%22`;
        }

        fetch(`https://meta.et4.de/rest.ashx/search/?experience=statistik_sachsen&type=City${query}&template=ET2014A.xml`)
            .then(response => response.ok ? response.text() : Promise.reject(response.status))
            .then(data => {
                const parser = new DOMParser();
                const xmlDoc = parser.parseFromString(data, 'application/xml');
                const items = xmlDoc.getElementsByTagName('item');

                const dropdown = document.createElement('select');
                dropdown.id = 'places-dropdown';

                dropdown.innerHTML = '<option value="" selected>Keine Auswahl</option>';
                Array.from(items).forEach(item => {
                    const title = item.getElementsByTagName('title')[0]?.textContent;
                    if (title) {
                        const option = document.createElement('option');
                        option.textContent = title;
                        option.value = title;
                        dropdown.appendChild(option);
                    }
                });

                elements.placeContainer.innerHTML = '';
                elements.placeContainer.appendChild(dropdown);

                dropdown.addEventListener('change', () => {
                    selectedPlace = dropdown.value || null;
                });
            })
            .catch(error => {
                console.error('Fehler beim Laden der Orte:', error);
                elements.placeContainer.textContent = 'Fehler beim Laden der Orte.';
            });
    };

    const loadCategories = (type) => {
        fetch(xmlUrls[type])
            .then(response => response.ok ? response.text() : Promise.reject(response.status))
            .then(data => {
                const parser = new DOMParser();
                const xmlDoc = parser.parseFromString(data, 'application/xml');
                const rootCategories = xmlDoc.getElementsByTagName('Category');

                categories = Array.from(rootCategories).map(category => category.getAttribute('Name'));
            })
            .catch(error => {
                console.error('Fehler beim Laden der Kategorien:', error);
            });
    };


 const loadAreas = () => {
        fetch('https://meta.et4.de/rest.ashx/search/?experience=statistik_sachsen&type=Area&template=ET2014A.xml')
            .then(response => response.ok ? response.text() : Promise.reject(response.status))
            .then(data => {
                const parser = new DOMParser();
                const xmlDoc = parser.parseFromString(data, 'application/xml');
                const areas = xmlDoc.getElementsByTagName('item');

                const dropdown = document.createElement('select');
                dropdown.id = 'areas-dropdown';

                dropdown.innerHTML = '<option value="" selected>Keine Auswahl</option>';
                Array.from(areas).forEach(area => {
                    const title = area.getElementsByTagName('title')[0]?.textContent;
                    if (title) {
                        const option = document.createElement('option');
                        option.textContent = title;
                        option.value = title;
                        dropdown.appendChild(option);
                    }
                });

                elements.areaContainer.innerHTML = '';
                elements.areaContainer.appendChild(dropdown);

                dropdown.addEventListener('change', () => {
                    selectedArea = dropdown.value || null;
                    loadPlaces(selectedArea);
                });
            })
            .catch(error => {
                console.error('Fehler beim Laden der Gebiete:', error);
                elements.areaContainer.textContent = 'Fehler beim Laden der Gebiete.';
            });
    };

    const loadTypes = () => {
        const typeDropdown = document.createElement('select');
        typeDropdown.id = 'type-dropdown';
        typeDropdown.innerHTML = '<option value="" selected>Keine Auswahl</option>';
        ['POI', 'Tour', 'Hotel', 'Event', 'Gastro'].forEach(type => {
            const option = document.createElement('option');
            option.textContent = type;
            option.value = type;
            typeDropdown.appendChild(option);
        });
        elements.typeContainer.innerHTML = '';
        elements.typeContainer.appendChild(typeDropdown);

        typeDropdown.addEventListener('change', () => {
            selectedType = typeDropdown.value;
            if (selectedType) loadCategories(selectedType);
        });
    };

    elements.allAreasCheckbox.addEventListener('change', () => {
        const isChecked = elements.allAreasCheckbox.checked;
        disableInputs(isChecked);
    });

    loadAreas();
    loadTypes();

    elements.button.addEventListener('click', () => {
        elements.resultDiv.innerHTML = '';
        elements.generatedUrlDiv.innerHTML = '';
        elements.chartContainer.style.display = 'none';

        toggleLoading(true);
        fetchData();
    });
});
